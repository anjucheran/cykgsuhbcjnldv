export default {
    getFormData(state) {
        return state.formData;
    },
    getAccessToken(state) {
      return state.accessToken;
    }
}
